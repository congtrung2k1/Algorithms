#include <bits/stdc++.h>
using namespace std;
#define ll long long

int n, a[200010];

int main(){
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("XORSUM.inp","r",stdin);
	freopen("XORSUM.out","w",stdout);

	ll n, ans = 0; cin >> n;
	for (int i = 0; i < 51; i++)
		if ((1LL << i) > n) break; else
		if (((n >> i) & 1) == 0) ans++;
	cout << (1LL << ans);

	return 0;
}