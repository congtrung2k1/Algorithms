#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n;
    cin >> n;
    if (n == 1)
    {
        cout << 1;
        return 0;
    }
    int res = 2;
    n--;
    for(int i = 2; i <= n; ++i)
        for(int j = 1; j <= i-1; ++j)
        {
            if (n <= i) break;
            if (__gcd(i,j) == 1)
            {
                res++;
                n -= i;
            }
        }
    cout << res;
}
