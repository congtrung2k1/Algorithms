/*
Gọi maxA là phần tử lớn nhất trong dãy.

Duyệt tất cả phần tử a[i] trong dãy.

Nếu (maxX-a[i]) chia hết cho x thì chi phí biến đổi cho a[i] là (maxX-a[i])/x, ngược lại thì không có cách biến đổi.

Độ phức tạp: O(n)
*/

#include <bits/stdc++.h>

using namespace std;

const int maxN = 1005;
int a[maxN];

int main() {
    freopen("incequal.inp", "r", stdin);
    freopen("incequal.out", "w", stdout);

    int n, x;
    cin >> n >> x;

    for(int i = 0; i < n; ++i)
        cin >> a[i];

    int maxA = *max_element(a, a+n);

    int ans = 0;
    for(int i = 0; i < n; ++i) {
        if ((maxA-a[i])%x != 0) {
            cout << -1;
            return 0;
        } else
            ans += (maxA-a[i])/x;
    }

    cout << ans;

    return 0;
}
