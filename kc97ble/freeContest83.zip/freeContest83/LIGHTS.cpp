/*
	OR  để bật bit
	XOR để đảo bit
	Gọi x là những bóng đèn ta tác động
	Gọi C là trạng thái của dãy 1..n/2-1 (n/2..n) bóng đèn
	Lần lượt thử trạng thái của 1 nửa bóng trước rồi so sánh 
xem trạng thái hợp với nửa sau có xuất hiện không
*/

#include <bits/stdc++.h>
using namespace std;
#define ll long long

int n,m,ans;
map<ll,ll> mp;
vector<int> a[36];

void dp(int i, ll x, ll C){
	if (i == n / 2){
		mp[C] = x;
		return;
	}

	dp(i + 1, x, C);

	x |= (1LL << i);
	C ^= (1LL << i);
	for (int j = 0; j < a[i].size(); j++) C ^= (1LL << a[i][j]);
	dp(i + 1, x, C);
}

void dp2(int i, ll x, ll C){
	if (i == n){
		C = ((1LL << n) - 1) ^ C;
		if (mp.count(C)){
			ll t = x | mp[C];
			int dem = 0;
			for (int j = 0; j < 35; j++)
				if ((1LL << j) > t) break; else
				if (t & (1LL << j)) dem++;
			ans = min(ans, dem);
		}
		return;
	}

	dp2(i + 1, x, C);

	x |= (1LL << i);
	C ^= (1LL << i);
	for (int j = 0; j < a[i].size(); j++) C ^= (1LL << a[i][j]);
	dp2(i + 1, x, C);
}

int main(){
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("LIGHTS.inp","r",stdin);
	freopen("LIGHTS.out","w",stdout);

	cin >> n >> m;
	for (int i = 0; i < m; i++){
		int u,v; cin >> u >> v;
		u--; v--;
		a[u].push_back(v);
		a[v].push_back(u);
	}

	dp(0,0,0);
	ans = 36;
	dp2(n/2,0,0);
	cout << ans;

	return 0;
}