#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ii pair<int, int>
#define fi first
#define se second

priority_queue<int> heap;
int n;
ii a[200005];

int main(){
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    freopen("CAKE.inp","r",stdin);
    freopen("CAKE.out","w",stdout);

    cin >> n;
    for (int i = 1; i <= n; i++) cin >> a[i].se >> a[i].fi;

    sort(a + 1, a + n + 1);
    ll sum = 0;
    int fuckingmousetime, cnt = 0;
    for (int i = 1; i <= n; i++){
        fuckingmousetime = a[i].fi;
        heap.push(a[i].se);
        sum += a[i].se;
        if (sum > fuckingmousetime) {
            sum -= heap.top();
            heap.pop();
            ++cnt;
        }
    }
    cout << n-cnt;

    return 0;
}
