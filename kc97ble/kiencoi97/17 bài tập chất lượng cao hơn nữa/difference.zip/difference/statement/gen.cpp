#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
using namespace std;

int main() {
    freopen("run.bat","w",stdout);
    int T = 31;
    for (int i = 1; i <= 5; i++) {
            printf("ren roz%docen.in differ.in.%d\n", i, T);
            printf("ren roz%docen.out differ.expect.%d\n", i, T);
            T++;
        }
}
