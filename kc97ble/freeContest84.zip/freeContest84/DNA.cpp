#include <bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	
	string s; cin >> s;
	int n; cin >> n;
	for (int i = 0; i < n; i++){
		string t;  cin >> t;
		if (t.length() != s.length()) continue;
		int d = 0;
		for (int j = 0; j < t.length(); j++) if (s[j] != t[j]) d++;
		if (d < 3) cout << i + 1 << " ";
	}

	return 0;
}