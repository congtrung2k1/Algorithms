#include <bits/stdc++.h>
using namespace std;

int main(){
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("numadd.inp","r",stdin);
	freopen("numadd.out","w",stdout);
	
	int q; cin >> q;
	while (q--){
		int n, a[101];
		cin >> n;
    	for (int i = 0; i < n; i++) cin >> a[i];
    	
    	int ans = 0, res = 0;
    	for (int i = 0; i < n; i++){
        	ans = __gcd(ans, a[i]);
        	res = max(res, a[i]);
    	}
    	res /= ans;
   		
   		if ((res - n) & 1) cout << "1"; else  cout << "0";
	}

	return 0;
}
