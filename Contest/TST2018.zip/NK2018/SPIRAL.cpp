#include <bits/stdc++.h>
using namespace std;

void io(){
    freopen("SPIRAL.INP","r",stdin);
    freopen("SPIRAL.OUT","w",stdout);
}

int main(){
    io();
    int n; cin >> n;

    long long ans = n , tmp = n;
    for (int i = 1 ; i <= n - 1 ; i++){
        tmp += (n - i) * 2;
        ans += tmp;
    }

    cout << ans;

    return 0;
}
s