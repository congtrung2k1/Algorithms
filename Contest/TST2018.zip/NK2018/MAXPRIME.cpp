#include <bits/stdc++.h>
using namespace std;

void io(){
    freopen("MAXPRIME.INP","r",stdin);
    freopen("MAXPRIME.OUT","w",stdout);
}

double doi(char s , int i){
    return (int)(s - 48) * (double)pow(10 , i);
}

bool ngto(double x){
    int s = x;
    for (int i = 2 ; i <= sqrt(s) ; i++)
        if (s % i == 0) return false;
    return true;
}

int main(){
    io();
    string s; cin >> s;

    int q = 0 , w = 0;
    double tmp = 0;
    for (int i = 0 ; i < s.length() ; i++)
        if (s[i] != '?')
            tmp += doi(s[i] , s.length() - i - 1);
        else
            q = w , w = i;

    for (char i = '9' ; i > '0'; i--)
        for (char j = '9' ; j > '0' ; j--)
            if (ngto( tmp + doi(i , s.length() - q - 1) + doi(j , s.length() - w - 1) )){
                s[q] = i;
                s[w] = j;
                cout << s;
                return 0;
            }
}
