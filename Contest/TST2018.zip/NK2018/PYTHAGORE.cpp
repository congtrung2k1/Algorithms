#include <bits/stdc++.h>
using namespace std;

int dp[5001];

int main(){
    freopen("PYTHAGORE.INP","r",stdin);
    freopen("PYTHAGORE.OUT","w",stdout);

    for (int i = 1 ; i <= 70 ; i++)
        for (int j = 1 ; j <= i ; j++)
            for (int k = 1 ; k <= j ; k++)
                if (k * k + j * j == i * i)
                    dp[k + j + i]++;

    int n; cin >> n;
    for (int i = 1 ; i <= n ; i++){
        int x; cin >> x;
        cout << dp[x] << '\n';
    }

    return 0;
}
