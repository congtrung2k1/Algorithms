/*
USER: zobayer
TASK: MAXLN
ALGO: geometry
*/

#include<ios>
int main(){int r,t,c=1;for(scanf("%d",&t);t--;){scanf("%d",&r);printf("Case %d: %lld.25\n",c++,(long long)r*r<<2);}return 0;}