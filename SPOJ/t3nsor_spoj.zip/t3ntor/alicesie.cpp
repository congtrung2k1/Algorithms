// 2014-04-30
#include <iostream>
using namespace std;
int main() {
    int T; cin >> T;
    while (T--) {
        int N; cin >> N; cout << (N+1)/2 << endl;
    }
}
