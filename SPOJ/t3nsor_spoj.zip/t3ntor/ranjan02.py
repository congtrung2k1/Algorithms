# 2014-10-01
t = int(raw_input())
for i in xrange(t):
    n = int(raw_input())
    print 3**n-1
