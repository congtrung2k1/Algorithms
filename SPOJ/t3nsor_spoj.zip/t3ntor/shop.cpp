// 2008-06-04
#include <iostream>
#include <string>
#include <queue>
using namespace std;
int main()
{
	for(;;)
	{
		cin >> X >> Y;
		if (X==0)
			return 0;
		for (i=0; i<Y; i++)
		{
			cin >> S;
			for (j=0; j<X; j++)

		}
	}
}
