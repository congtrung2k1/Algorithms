#include <bits/stdc++.h>
using namespace std;

int n;
string a,b;
long long ans = 0;
long long dp[16][2][2][2];

long long tinh(int i , bool la , bool nb , bool c1){
    if (dp[i][la][nb][c1] != -1) return dp[i][la][nb][c1];
    if ( i == n){
        dp[i][la][nb][c1] = 1;
        return 1;
    }

    dp[i][la][nb][c1] = 0;
    for (char c = '0' ; c <= '9' ; c++)
        if ( (la || c >= a[i]) && (nb || c <= b[i]) && (!c1 || c != '3'))
            dp[i][la][nb][c1] += tinh(i + 1 , la || c > a[i] , nb || c < b[i] , c == '1');

    return dp[i][la][nb][c1];
}

int main(){
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    freopen("input.inp","r",stdin);

while (cin >> a){
    cin >> b;
    while (a.length() < b.length()) a = '0' + a;
    n = a.length();

    ans = 0;
    memset(dp , 255 , sizeof(dp));
    for (char c = a[0] ; c <= b[0] ; c++)
        ans += tinh(1 , c > a[0] , c < b[0], c == '1');

    cout << ans << '\n';
}

    return 0;
}
