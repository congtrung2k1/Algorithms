#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int n;
string a,b;
ll dp[20][10][10][2][2][2];

ll tinh(int i , char la , char lb , bool oka , bool okb , bool mean){
    if (dp[i][la - 48][lb - 48][oka][okb][mean] != -1) return dp[i][la - 48][lb - 48][oka][okb][mean];
    if (i == n) return 1;

    dp[i][la - 48][lb - 48][oka][okb][mean] = 0;
    for (char c = '0' ; c <= '9' ; c++)
        if ( (oka || a[i] <= c) && (okb || c <= b[i]) && ( (!mean && c == '0') || (c != la && c!= lb) ) )
            dp[i][la - 48][lb - 48][oka][okb][mean] += tinh(i + 1 , lb , c , oka || a[i] < c , okb || c < b[i] , mean || lb != '0');

    return dp[i][la - 48][lb - 48][oka][okb][mean];
}

int main(){
    cin >> a >> b;
    while (a.length() < b.length()) a = '0' + a;
    n = a.length();

    memset(dp,255,sizeof(dp));
    ll ans = tinh(0 , '0' , '0' , false , false , false);

    cout << ans;

    return 0;
}
