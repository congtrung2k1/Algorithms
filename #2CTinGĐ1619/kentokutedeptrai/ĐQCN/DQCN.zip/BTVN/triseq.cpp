#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int n , t;
ll dp[20][20][20][20];
int s[20] , trade[20];

ll tinh(int i , int a , int b , int c){
    if (a + b <= c) return 0;
    if (i > n) return 1;
    if (dp[i][a][b][c] != -1) return dp[i][a][b][c];

    dp[i][a][b][c] = 0;
    for (int j = 1 ; j <= n ; j++)
        if (j < a) dp[i][a][b][c] += tinh(i + 1 , j , a , max(c , j));
        else       dp[i][a][b][c] += tinh(i + 1 , a , min(b , j) , max(c , j));

    return dp[i][a][b][c];
}

void trade1(int i , int a , int b , int c){
    if (i > n) return;
    for (int j = 1 ; j <= n ; j++)
        if (j < a){
            ll tmp = tinh(i + 1 , j , a , max(c , j));
            if (t > tmp) t -= tmp;
            else
            {
                trade[i] = j;
                trade1(i + 1 , j , a , max(c , j));
                return;
            }
        }
        else{
            ll tmp = tinh(i + 1 , a , min(b , j) , max(c , j));
            if (t > tmp) t -= tmp;
            else
            {
                trade[i] = j;
                trade1(i + 1 , a , min(b , j) , max(c , j));
                return;
            }
        }
}

void trade2(int i , int a , int b , int c){
    if (i > n) return;
    int x = s[i] - 1;
    for (int j = 1 ; j <= x ; j++)
        if (j < a) t += tinh(i + 1 , j , a , max(c , j));
        else       t += tinh(i + 1 , a , min(b , j) , max(c , j));
    if (s[i] < a) trade2(i + 1 , s[i] , a , max(c , s[i]));
    else          trade2(i + 1 , a , min(b , s[i]) , max(c , s[i]));
}

int main(){
    cin >> n >> t;
    for (int i = 1 ; i <= n ; i++) cin >> s[i];

    memset(dp,255,sizeof(dp));
    ll ans = tinh(1 , n + 1 , n + 1 , 0);
    cout << ans << '\n';

    trade1(1 , n + 1 , n + 1 , 0);
    for (int i = 1 ; i <= n ; i++) cout << trade[i] << " "; cout << '\n';

    t = 1;
    trade2(1 , n + 1 , n + 1, 0);
    cout << t;

    return 0;
}
