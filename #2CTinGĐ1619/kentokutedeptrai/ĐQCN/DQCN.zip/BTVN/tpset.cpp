#include <bits/stdc++.h>
#include <limits>
using namespace std;
typedef long long ll;

ll n , base = 1e18;

struct bignum{ ll a,b; } s[65] , re;

bignum operator +(bignum x , bignum y){
    bignum z;
    z.b = (x.b + y.b) % base;
    z.a = (x.a + y.a) + ((x.b + y.b) / base);
    return z;
}

string chuyen(ll x){
    string s = "";
    while (x != 0){
        s = char(x % 10 + 48) + s;
        x /= 10;
    }
    while (s.length() < 18) s = '0' + s;
    return s;
}

int main(){
    s[1].a = 0; s[1].b = 1;
    for (int i = 2 ; i <= 63 ; i++) s[i] = s[i-1] + s[i-1] + s[i-1];

    while (cin >> n){
        re = s[0];
        for (int i = 1 ; i <= 63 ; i++)
            if ((n >> (i-1)) & 1) re = re + s[i];
        if (re.a != 0){
            string x = chuyen(re.b);
            printf("%ld%s\n", re.a, x);
        }
        else cout << re.b << "\n";
    }

    return 0;
}
