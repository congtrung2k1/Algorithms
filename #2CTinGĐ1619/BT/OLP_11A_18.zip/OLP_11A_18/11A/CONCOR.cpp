#include <iostream>
#include <stdio.h>
#include <math.h>
#include <algorithm>

using namespace std;

int sqr(int x) {
    return x * x;
}

int dis(int x, int y, int x1, int y1, int x2, int y2) {
    int a = sqr(x - x1) + sqr(y - y1),
        b = sqr(x - x2) + sqr(y - y2),
        c = sqr(x1 - x2) + sqr(y1 - y2);
    if (a > b + c || b > c + a) return ceil(sqrt(min(a, b)));
    return ceil((double) abs((x - x1) * (y - y2) - (x - x2) * (y - y1)) / sqrt(c));
}

int s, n, d, x[2010], y[2010], r[2010], m[2010];
long long res = 0;
bool _get[2010];

int main() {
    freopen("concor.inp", "r", stdin);
    freopen("concor.out", "w", stdout);
    cin >> s >> n >> d;
    for (int i = 0; i < s; i++)
        cin >> x[i] >> y[i] >> r[i] >> m[i];
    for (int x1 = 0, y1 = 0, x2, y2; n >= 0; x1 = x2, y1 = y2, n--) {
        if (n) cin >> x2 >> y2;
        else x2 = y2 = 0;
        for (int i = 0; i < s; i++)
            if (!_get[i] && dis(x[i], y[i], x1, y1, x2, y2) <= d + r[i])
                res += m[i], _get[i] = true;
    }
    cout << res;
}

/// Source: Olympic 30/4 grade 11 A (2018)
/// Code by James L. Wolfris