#include <iostream>
#include <stdio.h>

using namespace std;

const int MOD = 1e8;

void inc(int &x, int y) {
    x = (x + y) % MOD;
}

int q, f, fL, fR;
string s, t;

int main() {
    freopen("btree.inp", "r", stdin);
    freopen("btree.out", "w", stdout);
    cin >> q;
    while (q--) {
        cin >> s >> t;
        f = fL = fR = 1;
        for (int i = 1, j = s.length() - 1, u = 0; i < t.length(); i++) {
            if (t[i] == 'L')
                inc(f, fL), inc(fR, fL);
            else if (t[i] == 'R')
                inc(f, fR), inc(fL, fR);
            else if (j > 0) {
                do {
                    if (s[j] == 'U') u++;
                    else if (u > 0) u--;
                    else {
                        if (s[j] == 'L')
                            inc(f, 1), inc(fR, 1);
                        else if (s[j] == 'R')
                            inc(f, 1), inc(fL, 1);
                        j--; break;
                    }
                    j--;
                } while (j > 0);
            }
        }
        cout << f << '\n';
    }
}

/// Source: Olympic 30/4 grade 11 A (2018)
/// Code by James L. Wolfris