#include <iostream>
#include <stdio.h>
#include <algorithm>

using namespace std;

int n, k, id[300010];
long long res, f[300010], s[300010];

bool cmp(int i, int j) {
    return s[i] < s[j] || (s[i] == s[j] && i < j);
}

int main() {
    freopen("rate.inp", "r", stdin);
    freopen("rate.out", "w", stdout);
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        int tmp; cin >> tmp;
        f[i] = f[i - 1] + tmp;
    }
    long long l = 1, r = 1e12;
    while (l <= r) {
        long long m = (l + r) / 2;
        for (int i = 0; i <= n; i++)
            s[i] = f[i] * 1e6 - m * i,
            id[i] = i;
        sort(id, id + n + 1, cmp);
        int len = 0;
        for (int idmin = id[0], i = 1; i <= n; i++)
            len = max(len, id[i] - idmin),
            idmin = min(idmin, id[i]);
        if (len >= k) res = m, l = m + 1;
        else r = m - 1;
    }
    cout << res / 1000000 << '.';
    for (int i = 1e5; i >= 1; i /= 10)
        cout << res / i % 10;
}

/// Source: Olympic 30/4 grade 11 A (2018)
/// Code by James L. Wolfris