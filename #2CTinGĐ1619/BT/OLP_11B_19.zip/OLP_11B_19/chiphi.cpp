#include <bits/stdc++.h>
using namespace std;
#define oo 10000000000

int n,m,k, dinh[251], T[251];
long long c[251][251], maxT[251][251];

int main() {
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("chiphi.inp","r",stdin);
	freopen("chiphi.out","w",stdout);

	cin >> n >> m >> k;
	for (int i = 1; i <= n; i++) {
		cin >> T[i];
		dinh[i] = i;
	}

	for (int i = 1; i < n; i++)
		for (int j = i + 1; j <= n; j++)
			if (T[dinh[i]] > T[dinh[j]]) {
				int tmp = dinh[i];
				dinh[i] = dinh[j];
				dinh[j] = tmp;
			}

	for (int i = 1; i <= n; i++) for (int j = 1; j <= n; j++) c[i][j] = oo, maxT[i][j] = oo;

	for (int u,v,l,i = 1; i <= m; i++) {
		cin >> u >> v >> l;
		if (c[u][v] > l) c[u][v] = l;
		c[v][u] = c[u][v];
	}

	for (int l = 1; l <= n; l++) {
		int k = l;
		for (int u = 1; u <= n; u++)
			for (int v = 1; v <= n; v++)
				if (c[u][v] >= c[u][k] + c[k][v]) {
					c[u][v] = c[u][k] + c[k][v];
					maxT[u][v] = min(maxT[u][v], c[u][v] + max(T[u], max(T[v], T[k])));
				}
	}

	for (int u,v,i = 1; i <= k; i++) {
		cin >> u >> v;
		cout << maxT[u][v] << '\n';
	}
}

