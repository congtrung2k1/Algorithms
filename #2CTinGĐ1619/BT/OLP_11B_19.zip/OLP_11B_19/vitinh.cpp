#include <bits/stdc++.h>
using namespace std;
#define ll long long

int n;
ll a[17];

int main(){
	ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("vitinh.inp","r",stdin); 
	freopen("vitinh.out","w",stdout);

	cin >> n;
	a[0] = 0;
	ll f = 1, e = 9;
	for (int i = 1; i <= 16; i++, f *= 10, e = e * 10 + 9) a[i] = e - f + 1;
	
	int c = 1;
	ll re = 0;
	while (n > 0) {
		re += n;
		n -= a[c++];
		if (n <= 0) break;
	}

	cout << re;
}