#include "werewolf.h"

std::vector<int> check_validity(int N, std::vector<int> X, std::vector<int> Y,
                                std::vector<int> S, std::vector<int> E,
                                std::vector<int> L, std::vector<int> R) {
  int Q = S.size();
  std::vector<int> A(Q);
  for (int i = 0; i < Q; ++i) {
    A[i] = 0;
  }
  return A;
}
