public class werewolf {
  int[] check_validity(int N, int[] X, int[] Y, int[] S, int[] E, int[] L, int[] R) {
    int Q = S.length;
    int[] A = new int[Q];
    for (int i = 0; i < Q; ++i) {
      A[i] = 0;
    }
    return A;
  }
}
