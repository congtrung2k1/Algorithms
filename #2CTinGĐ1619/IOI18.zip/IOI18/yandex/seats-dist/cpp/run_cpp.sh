#!/bin/bash

TASK=seats

./${TASK}
