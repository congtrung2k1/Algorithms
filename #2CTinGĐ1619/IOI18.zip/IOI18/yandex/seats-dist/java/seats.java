public class seats {
  void give_initial_chart(int H, int W, int[] R, int[] C) {
    r = R;
  }

  int swap_seats(int a, int b) {
    return r[a];
  }

  int[] r;
}
