#include <bits/stdc++.h>
using namespace std;

int n, m;
bool fre[10000], a[10000][10000];

void dfs(int u){
	fre[u] = true;
	for (int i = 1; i <= n; i++)
		if (a[u][i] && !fre[i]) dfs(i);
}

int main(){
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("route.inp","r",stdin);
	freopen("route.out","w",stdout);

	cin >> n >> m;
	for (int u,v, i = 1; i <= m; i++) cin >> u >> v, a[u][v] = true, a[v][u] = true;

	int ans = 0;
	for (int i = 1; i <= n; i++) if (!fre[i]) ans++, dfs(i);
	cout << ans*(ans - 1) / 2;

	return 0;
}