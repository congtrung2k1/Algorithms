#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define ii pair<int,int>
#define fi first
#define se second
#define ss 10000000

priority_queue<ii, vector<ii>, greater<ii> > q;
bool fre[ss];

int main(){
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("search.inp","r",stdin);
	freopen("search.out","w",stdout);

	int n,k; cin >> n >> k;

	q.push(ii(0,n)); 
	fre[n] = true;

	while (!q.empty()) {
		ii tmp = q.top();
		int u = tmp.se, b = tmp.fi;
		q.pop();

		if (u - 1 > 0 && !fre[u - 1]) {
			fre[u - 1] = true;
			q.push(ii(b + 1, u - 1));
		}
		if (u + 1 < ss && !fre[u + 1]) {
			fre[u + 1] = true;
			q.push(ii(b + 1, u + 1));
		}
		if (2 * u < ss && !fre[2 * u]) {
			fre[2 * u] = true;
			q.push(ii(b + 1, 2 * u));
		}

		if (u - 1 == k || u + 1 == k || 2 * u == k) {
			cout << b + 1;
			break;
		}
	}

	return 0;
}