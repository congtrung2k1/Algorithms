#include<bits/stdc++.h>
using namespace std;

int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("input.inp","r",stdin);
	freopen("input.out","w",stdout);

	int n,m, ans[1000][1000], dao[100000];
	cin >> n >> m;
	for (int i = 1; i <= m; i++) cin >> dao[i];
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++) cin >> ans[i][j];

	for (int k = 1; k <= n; k++)
		for (int u = 1; u <= n; u++)
			for (int v = 1; v <= n; v++)
				ans[u][v] = min(ans[u][v], ans[u][k] + ans[k][v]);

	long long dem = 0;
	for (int i = 1; i < m; i++) dem += ans[dao[i]][dao[i + 1]];
	cout << dem;

	return 0;
}