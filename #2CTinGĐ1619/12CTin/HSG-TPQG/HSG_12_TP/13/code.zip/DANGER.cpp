#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

void fileio() {freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);}

ll N, M;
ll route[10001], dp[101][101];

int main()
{
    freopen("DANGER.INP", "r", stdin); freopen("DANGER.OUT", "w", stdout);
    //fileio();
    cin >> N >> M;

    for (int i = 0; i < M; i++) cin >> route[i];
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            cin >> dp[i][j];
        }
    }

    for (int k = 1; k <= N; k++) {
        for (int u = 1; u <= N; u++) {
            for (int v = 1; v <= N; v++) {
                dp[u][v] = min(dp[u][v], dp[u][k] + dp[k][v]);
            }
        }
    }

    ll res = 0;

    if (route[0] != 1)
        res += dp[1][route[0]];
    if (route[M-1] != N)
        res += dp[route[M-1]][N];

    for (int i = 1; i < M; i++)
        res += dp[route[i-1]][route[i]];

    cout << res;
    return 0;
}
