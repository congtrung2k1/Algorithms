#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

void fileio() {freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);}

int N, M, res = 0;
vector<int> a[2001];
bool vst[2001];

void dfs(int u) {
    vst[u] = 1;
    for (int i = 0; i < (int)a[u].size(); i++)
        if (!vst[a[u][i]]) dfs(a[u][i]);
}

int main()
{
    freopen("ROUTE.INP", "r", stdin); freopen("ROUTE.OUT", "w", stdout);
    //fileio();
    cin >> N >> M;
    for (int i = 0; i < M; i++) {
        int u, v;
        cin >> u >> v;
        a[u].push_back(v);
        a[v].push_back(u);
    }
    memset(vst, 0, sizeof vst);
    for (int i = 1; i <= N; i++) {
        if (vst[i] == 0) {
            dfs(i);
            res++;
        }
    }
    res = (res * (res - 1)) / 2;
    cout << res;
    return 0;
}
