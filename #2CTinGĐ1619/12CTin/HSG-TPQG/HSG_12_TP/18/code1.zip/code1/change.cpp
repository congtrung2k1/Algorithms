#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int n, k;
string dp[1010][110];

string cong(string a, string b){
    string ans = "";
    while (a.length() < b.length()) a = "0" + a;
    while (a.length() > b.length()) b = "0" + b;
    int du = 0;
    for (int i = a.length()-1; i >= 0; i--){
        int t = a[i] + b[i] + du - 96;
        char c = (t % 10) + 48;
        ans = c + ans;
        du = t/10;
    }
    if (du) ans = "1" + ans;
    return ans;
}

int main(){
    freopen("change.inp", "r", stdin);
    freopen("change.out", "w", stdout);

    cin >> n >> k;
    for (int i = 1; i <= n; i++) dp[i][0] = "0";
    for (int i = 1; i <= k; i++) dp[0][i] = "1";

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= k; j++)
            if (i >= j)
                dp[i][j] = cong(dp[i][j-1] , dp[i - j][j]);
            else
                dp[i][j] = dp[i][j-1];

    cout << dp[n][k];

    return 0;
}
