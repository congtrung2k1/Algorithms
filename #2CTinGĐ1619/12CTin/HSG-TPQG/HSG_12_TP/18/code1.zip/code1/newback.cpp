#include <bits/stdc++.h>
using namespace std;

struct type{
	int p,v,c;
} a[101];

bool cmp(type a, type b){
	return a.p > b.p || a.p == b.p && a.v < b.v || a.p == b.p && a.v == b.v && a.c > b.c;
}

int n,v0, dp[101][100001];

int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("newback.inp","r",stdin);
	freopen("newback.out","w",stdout);

	cin >> n >> v0;
	for (int i = 1; i <= n; i++) {
		cin >> a[i].v >> a[i].c >> a[i].p;
	}
	sort(a + 1, a + n + 1, cmp);

	dp[0][0] = 0; pp[0][0] = 0;
	for (int i = 1; i <= n; i++) {
		dp[i][0] = 0; pp[i][0] = 0;

		for (int j = 1; j <= v0 + a[i].p; j++) {
			dp[i][j] = dp[i-1][j];
			pp[i][j] = pp[i-1][j];

			if (dp[i][j] > dp[i-1][j-a[i].v])
				if (a[i].p > )

			dp[i][j] = max(dp[i - 1][j] , dp[i - 1][j - a[i].v] + a[i].c);
		}
	}

	cout << dp[n][v0];
	cout << endl;
	for (int i = 1; i <= n; i++){
		for (int j = 1; j <= v0; j++) cout <<dp[i][j] << ' '; cout << endl;}

}