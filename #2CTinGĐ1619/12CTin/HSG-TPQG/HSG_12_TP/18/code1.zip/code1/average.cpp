#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct mang{
    int a,b;
} l[100010];
bool cmp(mang l, mang r){
    return l.a < r.a || (l.a == r.a && l.b < r.b);
}

int main(){
    freopen("average.inp", "r", stdin);
    freopen("average.out", "w", stdout);

    int n, k;
    ll a[100010];
    cin >> n >> k;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        a[i] -= k;
    }

    l[0].a = a[0]; l[0].b = 0;
    for (int i = 1; i < n; i++){
        l[i].a = l[i-1].a + a[i];
        l[i].b = i;
    }
    sort(l,l+n,cmp);

    int smax = 0, i = 0, j = 0;
    while (i < n && j < n){
        while (j < n && l[i].a == l[j].a) j++;
        smax = (smax > l[j-1].b - l[i].b) ? smax : l[j-1].b - l[i].b;
        i = j;
    }

    cout << smax;

    return 0;
}
