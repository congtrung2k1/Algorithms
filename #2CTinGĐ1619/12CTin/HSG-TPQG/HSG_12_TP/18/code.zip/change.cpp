#include <bits/stdc++.h>
using namespace std;

string dp[1001][101];

string inc(string a, string b){
    while (a.length() < b.length()) a = '0' + a;
    while (b.length() < a.length()) b = '0' + b;
    string c = "";
    int du = 0;
    for (int i = (int)a.length() - 1; i >= 0; i--){
        c = char((a[i] + b[i] - 96 + du) % 10 + 48) + c;
        du = (a[i] + b[i] - 96 + du) / 10;
    }
    while (b.length() > 0 && b[0] == '0') b.erase(b.begin());
    if (du == 1) c = '1' + c;
    return c;
}


int main(){
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    freopen("change.inp","r",stdin);
    freopen("change.out","w",stdout);

    int n, k; cin >> n >> k;
    for (int i = 1; i <= n; i++) dp[0][i] = '1';
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= k; j++){
            dp[i][j] = dp[i][j - 1];
            if (i >= j) dp[i][j] = inc(dp[i][j], dp[i - j][j]);
        }
    cout << dp[n][k];

    return 0;
}
