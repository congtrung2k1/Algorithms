#include <bits/stdc++.h>
using namespace std;

const int nmax = 101;
const int cmax = 100001;

int n,m;
int v[nmax], c[nmax], p[nmax], dp[nmax][cmax];

void qsort(int l, int r){
    int i = l, j = r, m = p[(l + r) / 2];
    while (i <= j){
        while (p[i] > m) i++;
        while (m > p[j]) j--;
        if (i <= j){
            swap(v[i],v[j]);
            swap(c[i],c[j]);
            swap(p[i],p[j]);
            i++; j--;
        }
    }
    if (l < j) qsort(l,j);
    if (i < r) qsort(i,r);
}

int main(){
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    freopen("newback.inp","r",stdin);
    freopen("newback.out","w",stdout);

    int n,m; cin >> n >> m;
    for (int i = 1; i <= n; i++) cin >> v[i] >> c[i] >> p[i];
    qsort(1,n);

    int ans = 0;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m + p[i]; j++){
            dp[i][j] = dp[i - 1][j];
            if (j >= v[i]) dp[i][j] = max(dp[i][j], dp[i-1][j-v[i]] + c[i]);
            ans = max(ans, dp[i][j]);
        }
    cout << ans;

    return 0;
}
