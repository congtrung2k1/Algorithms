#include <bits/stdc++.h>
using namespace std;
#define ll long long

const int nmax = 100001;

ll a[nmax], b[nmax];

void qsort(int l, int r){
    int i = l, j = r;
    ll m = a[(l + r) / 2];

    while (i <= j){
        while (a[i] < m) i++;
        while (m < a[j]) j--;
        if (i <= j){
            swap(a[i],a[j]);
            swap(b[i],b[j]);
            i++; j--;
        }
    }

    if (l < j) qsort(l,j);
    if (i < r) qsort(i,r);
}

int main(){
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    freopen("average.inp","r",stdin);
    freopen("average.out","w",stdout);

    int n,k; cin >> n >> k;
    for (int i = 1; i <= n; i++){
        cin >> a[i];
        a[i] = a[i - 1] + a[i] - k;
        b[i] = i;
    }

    qsort(0,n);
    ll ans = 0;
    int x = b[1], y = b[1];
    for (int i = 1; i <= n; i++)
        if (a[i] == a[i - 1]){
            x = max(x, b[i]);
            y = min(y, b[i]);
        }
        else{
            ans = max(ans, x - y);
            x = b[i], y = b[i];
        }

    ans = max(ans, x - y);
    cout << ans;
    
    return 0;
}
