#include <iostream>
#include <cstdio>
#include <vector>
#include <queue>

#define FOR(i,a,b) for (int i = (a); i <= (b); i++)

using namespace std;

const int maxn = 1e5 + 5;
int n,m,k,d[maxn][4];
struct path
{
    int v,x,y;
    path() {}
    path(int V,int X,int Y) {v = V; x = X; y = Y;}
};
vector <path> a[maxn][2];
struct time
{
    int u,d;
    time() {}
    time(int U,int D) {u = U; d = D;}
};
struct cmp {bool operator() (time a,time b) {return a.d > b.d;}};

void dijkstra(int u,int z)
{
    FOR(i,1,n) d[i][z] = 1e9;
    d[u][z] = 0;
    priority_queue <time,vector <time>,cmp> q;
    q.push(time(u,0));
    while (!q.empty())
    {
        time X = q.top(); q.pop();
        u = X.u;
        if (d[u][z] != X.d) continue;
        FOR(i,0,(int)a[u][z > 1].size() - 1)
        {
            int v = a[u][z > 1][i].v,x;
            if (z <= 2) x = a[u][z > 1][i].y; else x = a[u][z > 1][i].x;
            if (d[v][z] > d[u][z] + x)
            {
                d[v][z] = d[u][z] + x;
                q.push(time(v,d[v][z]));
            }
        }
    }
}

int main()
{
    freopen("SCHOOL.INP","r",stdin);
    freopen("SCHOOL.OUT","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    FOR(i,1,m)
    {
        int u,v,x,y;
        scanf("%d%d%d%d",&u,&v,&x,&y);
        a[u][0].push_back(path(v,x,y));
        a[v][1].push_back(path(u,x,y));
    }
    FOR(u,1,n) FOR(i,0,(int)a[u][0].size() - 1)
    dijkstra(1,1); dijkstra(n,2); dijkstra(k,3);
//    FOR(i,1,n) cout << d[i][1] << " "; cout << "\n";
//    FOR(i,1,n) cout << d[i][2] << " "; cout << "\n";
//    FOR(i,1,n) cout << d[i][3] << " "; cout << "\n";
    int res = 1e9;
    FOR(i,1,n) if (d[i][1] + d[i][3] <= 59) res = min(res,d[i][1] + d[i][2]);
    cout << res;
    return 0;
}
