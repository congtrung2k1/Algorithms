#include <iostream>
#include <cstdio>
#include <queue>
#include <algorithm>

#define FOR(i,a,b) for (int i = (a); i <= (b); i++)

using namespace std;

const int ai[2][8] = {{-2,-2,-1,1,2, 2, 1,-1},{-1,-1,-1,0,1,1, 1, 0}};
const int aj[2][8] = {{-1, 1, 2,2,1,-1,-2,-2},{-1, 0, 1,1,1,0,-1,-1}};
int n,m,d[111][111][2];
bool a[111][111];
struct pos
{
    int x,y;
    pos() {}
    pos(int X,int Y) {x = X; y = Y;}
} s,t;

void bfs(pos u,int z)
{
    queue <pos> q;
    q.push(u);
    d[u.x][u.y][z] = 1;
    while (!q.empty())
    {
        u = q.front(); q.pop();
        int x = u.x,y = u.y;
        FOR(i,0,7)
        {
            int X = x + ai[z][i],Y = y + aj[z][i];
            if (X < 0 || Y < 0) continue;
            if (a[X][Y] && d[X][Y][z] == 0)
            {
                d[X][Y][z] = d[x][y][z] + 1;
                q.push(pos(X,Y));
            }
        }
    }
}

int able(int x,int y)
{
    int tmp = 0;
    FOR(i,0,7)
    {
        int X = x + ai[1][i],Y = y + aj[1][i],XX = x + ai[1][(i + 1) % 8],YY = y + aj[1][(i + 1) % 8];
        if (a[X][Y] && a[XX][YY]) if (d[X][Y][1] < d[x][y][1] || d[XX][YY][1] < d[x][y][1]) return 1; else tmp = 3;
    }
    for (int i = 1; i <= 7; i += 2)
    {
        int X = x + ai[1][i],Y = y + aj[1][i],XX = x + ai[1][(i + 2) % 8],YY = y + aj[1][(i + 2) % 8];
        if (a[X][Y] && a[XX][YY]) if (d[X][Y][1] < d[x][y][1] || d[XX][YY][1] < d[x][y][1]) return 1; else tmp = 3;
    }
    return tmp;
}

bool jump(int x,int y,int z)
{
    FOR(i,0,7)
    {
        int X = x + ai[z][i],Y = y + aj[z][i];
        if (d[X][Y][z] != 0) return true;
    }
    return false;
}

int main()
{
    freopen("MATOT.INP","r",stdin);
    freopen("MATOT.OUT","w",stdout);
    scanf("%d%d\n",&n,&m);
    FOR(i,1,n) a[i][0] = a[i][m + 1] = false;
    FOR(i,1,m) a[0][i] = a[n + 1][i] = false;
    FOR(i,1,n)
    {
        FOR(j,1,m)
        {
            char c;
            scanf("%c",&c);
            if (c == '#') a[i][j] = false; else a[i][j] = true;
            if (c == 'M') s = pos(i,j); else
            if (c == 'T') t = pos(i,j);
        }
        scanf("\n");
    }
    bfs(s,0); bfs(t,1);
    int res = 1e9;
//    FOR(i,1,n) {FOR(j,1,m) cout << d[i][j][0] << ' '; cout << '\n';} cout << '\n';
//    FOR(i,1,n) {FOR(j,1,m) cout << d[i][j][1] << ' '; cout << '\n';}
    FOR(i,1,n) FOR(j,1,m)
        if (d[i][j][0] == 0 || d[i][j][1] == 0) continue; else
        if (!jump(i,j,0) || !jump(i,j,1)) continue; else
        if (abs(d[i][j][0] - d[i][j][1]) % 2 == 0) res = min(res,max(d[i][j][0],d[i][j][1])); else
        if (able(i,j)) res = min(res,max(d[i][j][0],d[i][j][1] + able(i,j)));
    res--;
    if (res == 1e9 - 1) res = -1;
    printf("%d\n",res);
    return 0;
}
