#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <ctime>

#define FOR(i,a,b) for (int i = (a); i <= (b); i++)

using namespace std;

int n,m,k,d[22],D[22],DD[22],DDDD[22],a[22][22],tmp,res;
bool cmp(int i,int j) {return a[i][tmp] < a[j][tmp];}

bool check(int x,int n)
{
    FOR(i,1,n) if (x == DDDD[i]) return false;
    return true;
}

void TRY(int N)
{
    if (N >= res) return;
    bool kt = true;
    FOR(i,1,n) if (d[i] != D[i]) {kt = false; break;}
    if (kt)
    {
        res = N;
        FOR(i,1,N) DD[i] = DDDD[i];
        return;
    }
    int DDD[22];
    FOR(i,1,n) DDD[i] = d[i];
    FOR(i,1,m) if (check(i,N))
    {
        tmp = i;
        sort(d + 1,d + n + 1,cmp);
        DDDD[N + 1] = i;
        TRY(N + 1);
        FOR(j,1,n) d[j] = DDD[j];
    }
}

void testing()
{
    freopen("SCTAB.INP","w",stdout);
    srand(time(0));
    cout << "20 9 100\n";
    FOR(i,1,20) {FOR(j,1,9) cout << rand() % 100 + 1 << " "; cout << "\n";}
    FOR(i,1,100) cout << rand() % 9 + 1 << " ";
}

int main()
{
//    while (true)
//    {
//    testing();
    freopen("SCTAB.INP","r",stdin);
    freopen("SCTAB.OUT","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    FOR(i,1,n) d[i] = i;
    FOR(i,1,n) FOR(j,1,m) scanf("%d",&a[i][j]);
    FOR(i,1,k)
    {int x; scanf("%d",&x); tmp = x; sort(d + 1,d + n + 1,cmp);}
    FOR(i,1,n) {D[i] = d[i]; d[i] = i;}
    res = 10;
    TRY(0);
//    if (res == 3) break;
//    }
    cout << res << "\n";
    FOR(i,1,res) cout << DD[i] << "\n";
    return 0;
}
