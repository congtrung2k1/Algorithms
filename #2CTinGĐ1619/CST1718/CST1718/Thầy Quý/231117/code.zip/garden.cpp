#include <iostream>
using namespace std;

int n,m;
int dx[3] = {0, -1, -1};
int dy[3] = {-1, 0, -1};
int dp[1505][1505], cam[1505][1505], xoai[1505][1505];

int main(){
    freopen("input.inp","r",stdin);
    freopen("input.out","w",stdout);

    scanf("%d %d\n", &n, &m);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) {
            char c; int x; scanf("%c%d", &c, &x);
            if (c == 'C') cam[i][j] = x; else xoai[i][j] = x;
            cam[i][j] += cam[i - 1][j];
            xoai[i][j] += xoai[i - 1][j];
            scanf("%c",&c);
        }

    for (int i = 1; i <= m; i++) dp[1][i] = dp[1][i - 1] + cam[n][i] - cam[1][i];
    for (int i = 1; i <= n; i++) dp[i][1] = xoai[i - 1][1] + cam[n][1] - cam[i][1];

    for (int i = 2; i <= n; i++)
        for (int j = 2; j <= m; j++) {
            dp[i][j] = dp[i - 1][j] - (cam[i][j] - cam[i - 1][j]);

            for (int k = 1; k < 3; k++)
                dp[i][j] = max(dp[i][j], dp[i + dy[k]][j + dx[k]] + xoai[i - 1][j] + cam[n][j] - cam[i][j]);
        }

    cout << dp[n][m];
}