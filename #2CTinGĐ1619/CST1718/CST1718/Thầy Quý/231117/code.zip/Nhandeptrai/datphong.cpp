﻿//Nguyen Thanh Nhan
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>

#define maxN 200005
#define ii pair<int,int>
#define iii pair<int,ii>
#define fi first
#define se second
#define mp make_pair
#define ll long long

using namespace std;

///mỗi nút trong priority_queue q là iii <lợi nhuận, chỉ số của yêu cầu, chỉ số của phòng (đã sort) tương ứng>

int n,m,k; ii a[maxN],b[maxN]; priority_queue<iii> q; bool visited[maxN];

///Tìm kiếm nhị phân xem trong các phòng,
///phòng nào có sức chứa nhỏ nhất mà >= x.
int BS(int x)
{
    int l=1,r=n,res=0;
    while (l<=r)
    {
        int mid=(l+r)>>1;
        if (a[mid].fi>=x)
        {
            res=mid;
            r=mid-1;
        }
        else l=mid+1;
    }
    return res;
}

int main()
{
    freopen("datphong.inp","r",stdin);
    freopen("datphong.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);

	///a[i] là pair <sức chứa, tiền giữ chỗ>
	///b[i] là pair <sức chứa yêu cầu, tiền thuê phòng>
    for (int i=1; i<=n; i++) scanf("%d%d",&a[i].se,&a[i].fi);
    for (int i=1; i<=m; i++) scanf("%d%d",&b[i].se,&b[i].fi);
    sort(a+1,a+n+1);
    for (int i=1; i<=m; i++)
    {
        int pos=BS(b[i].fi);
        if (pos==0) continue; ///Không có bất kỳ phòng nào đáp ứng được!
        q.push(mp(b[i].se-a[pos].se,ii(i,pos)));
    }
    ll res=0;
    while (k--)
    {
        iii tmp;
		///Điều kiện thứ hai: visited... để xét xem
		///liệu phòng tương ứng đã đáp ứng cho yêu cầu nào khác chưa?

		///Block code này để giải quyết chuyện phòng của top() của heap
		///đã được đặt chỗ mất rồi.
        while (!q.empty() && visited[q.top().se.se])
        {
            tmp=q.top(); q.pop();
            if (tmp.se.se==n) continue; ///Chỉ phòng cuối cùng mới thích hợp với yêu cầu này.
			///Mà phòng cuối cùng là phòng lớn nhất rồi (sort theo p).
			///Do đó yêu cầu này hết hy vọng tiếp nhận, pop ra thôi.
            int x=tmp.se.fi,y=tmp.se.se+1;
			///Dò xem phòng tiếp theo, lớn hơn gần nhất còn tiếp nhận được khách là...?
			///Sau đó đẩy lại vào heap, trở thành ứng cử viên mới.
            while (visited[y] && y<=n) y++;
            if (y<=n)
                q.push(mp(b[x].se-a[y].se,ii(x,y)));
        }


        if (q.empty()) break; ///Hết yêu cầu!
        tmp=q.top(); q.pop();
        if (tmp.fi<=0) break; ///Không có lợi nhuận.
		///Mà do heap max theo lợi nhuận nên rõ ràng,
		///các phần tử tiếp theo của heap, lợi nhuận cũng sẽ <=0,
		///không break thì còn làm gì?
        visited[tmp.se.se]=true; ///Phòng đã được đặt, tiếp nhận yêu cầu.
        res+=1LL*tmp.fi;
    }
    cout<<res;
    return 0;
}
