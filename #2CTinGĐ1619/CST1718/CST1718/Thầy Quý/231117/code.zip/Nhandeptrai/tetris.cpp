﻿// Nguyen Thanh Nhan
#include <iostream>
#include <cstdio>

#define ll long long
#define maxN 255

using namespace std;
ll Pow[maxN][7],F[maxN][maxN][maxN]; int a[maxN],b[maxN],c[maxN],n; bool visited[maxN][maxN][maxN];

///Trạng thái (l,r,k) có nghĩa là:
///Số điểm lớn nhất có thể, khi ta giải quyết các block từ l tới r,
///mà có thêm k khối giống màu với a[r] chắp vào ngay phía sau.
ll calc(int l,int r,int k)
{
    if (l>r) return 0;
    if (l==r) return F[l][r][k]=Pow[c[l]+k][a[l]];
    if (visited[l][r][k]) return F[l][r][k];
    visited[l][r][k]=true;
	///Hốt cục cuối.
    F[l][r][k]=max(F[l][r][k],calc(l,r-1,0)+calc(r,r,k));

	///Chọn 1 cục phía trước để chắp vào, phần giữa tự giải quyết.
    for (int i=l; i<r; i++)
        if (a[i]==a[r])
            F[l][r][k]=max(F[l][r][k],calc(l,i,k+c[r])+calc(i+1,r-1,0));
    return F[l][r][k];
}

int main()
{
    freopen("tetris.inp","r",stdin);
    freopen("tetris.out","w",stdout);
	///Tính sẵn mảng lũy thừa, để tiện và cũng để dễ tính độ phức tạp.
    for (int i=1; i<=250; i++) Pow[i][0]=1;
    for (int i=1; i<=250; i++) for (int j=1; j<=5; j++) Pow[i][j]=Pow[i][j-1]*i;

    while (scanf("%d",&n)==1)
    {
        for (int i=1; i<=n; i++) scanf("%d",&b[i]);
		///Nén dãy lại: b[] là dãy ban đầu, a[] là dãy được nén, và c[] là dãy số lượng các ô liền nhau.
        int cnt=0;
        for (int i=1; i<=n; i++) if (b[i]!=b[i-1]) a[++cnt]=b[i],c[cnt]=1; else c[cnt]++;

        printf("%lld\n",calc(1,cnt,0));

		///Học tập: dùng 3 dấu / "///" để làm TODO trong Codeblocks (nổi bật hơn //)
		///Viết lan ra như vậy để nhắc nhớ (bài này quên reset là chết).
        for (int i=1; i<=cnt; i++) for (int j=1; j<=cnt; j++) for (int k=0; k<=n; k++) F[i][j][k]=visited[i][j][k]=0;
        ///resetttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt
    }
    return 0;
}
