﻿//Nguyen Thanh Nhan
#include <iostream>
#include <cstdio>

#define maxN 1505
#define ii pair<int,int>
#define fi first
#define se second

using namespace std;

///a[i][j] là pair <số lượng cây, cam(1) hay xoài(2)?>
///sum1[i][j] là tổng số cây cam trong hàng i, từ cột 1 đến cột j.
///sum2[i][j] ______________ xoài________________________________.
///F[i][j] là tổng số (xoài trên mương + cam dưới mương) lớn nhất có thể giữ lại khi xe ủi
///tới ô [i][j].
int m,n,sum1[maxN][maxN],sum2[maxN][maxN],F[maxN][maxN]; ii a[maxN][maxN];

int main()
{
    freopen("garden.inp","r",stdin);
    freopen("garden.out","w",stdout);
    char c; int x;
    scanf("%d%d\n",&m,&n);
    for (int i=1; i<=m; i++)
    {
        for (int j=1; j<=n; j++)
        {
            scanf("%c%d ",&c,&x);
            a[i][j].fi=x;
            if (c=='C') a[i][j].se=1;
            else if (c=='X') a[i][j].se=2;
        }
    }
	///Mảng tính sẵn, để đạt độ phức tạp O(N*N)
    for (int i=1; i<=m; i++) for (int j=1; j<=n; j++)
    {
        sum1[i][j]=sum1[i][j-1]+((a[i][j].se==1) ? a[i][j].fi : 0);
        sum2[i][j]=sum2[i][j-1]+((a[i][j].se==2) ? a[i][j].fi : 0);
    }

	///Chú ý cách cout mà không cần control xuống dòng
//    for (int i=1; i<=m; i++) for (int j=1; j<=n; j++) cout<<sum1[i][j]<<" \n"[j==n];
//    for (int i=1; i<=m; i++) for (int j=1; j<=n; j++) cout<<sum2[i][j]<<" \n"[j==n];
    for (int i=1; i<=m; i++) F[i][0]=-long(1e9);
    for (int i=1; i<=n; i++) F[0][i]=-long(1e9);
    F[0][0]=0;

    for (int i=1; i<=m; i++) for (int j=1; j<=n; j++)
    {
		///Công thức truy hồi:
		/**
		1. Đi xuống dưới (từ ô bên trên đi xuống)
		F[i][j]=F[i-1][j] + (số cam hàng i, cột [1..j-1]) + (số xoài hàng i, cột [j+1..n])
		2. Đi chéo xuống (từ ô trái, trên đi xuống)
		F[i][j]=F[i-1][j-1] + (số cam hàng i, cột [1..j-1]) + (số xoài hàng i, cột [j+1..n])
		3. Đi ngang qua phải (từ ô bên trái đi qua)
		F[i][j]=F[i][j-1] - (số cây ở ô (i,j) nếu đó là xoài)

		Lấy max của 3 hướng này, ra F[i][j] cần tìm.
		**/
        F[i][j]=max(F[i-1][j]+sum1[i][j-1]+sum2[i][n]-sum2[i][j],max(F[i][j-1]-((a[i][j].se==2) ? a[i][j].fi : 0),F[i-1][j-1]+sum1[i][j-1]+sum2[i][n]-sum2[i][j]));
    }
    cout<<F[m][n];
//    for (int i=1; i<=m; i++) for (int j=1; j<=n; j++) cout<<F[i][j]<<" \n"[j==n];
    return 0;
}
