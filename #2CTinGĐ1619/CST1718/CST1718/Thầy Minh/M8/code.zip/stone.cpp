#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

vector<int> a[450];
int ans[450], n;

void dfs(int u, int la) {
    vector<int> soi;
    for (int v: a[u]) if (v != la) dfs(v,u);
    for (int v: a[u]) if (v != la) soi.push_back(ans[v]);
    sort(soi.begin(), soi.end());
    
    if ((int)soi.size() == 0){
        ans[u] = 1;
        return;
    }

    ans[u] = 0; 
    int now = 0;
    for (int v: soi)
        if (now < v)
            ans[u] += v - now, now = v - 1;
        else
            now--;
}

int main() {
    freopen("stone.inp","r",stdin);
    freopen("stone.out","w",stdout);

    cin >> n;
    for (int i = 1; i <= n; i++) {
        int u,v,m; cin >> u >> m;
        while(m--) 
            cin >> v,
            a[u].push_back(v),
            a[v].push_back(u);
    }
    dfs(1,0);
    cout << ans[1];
}