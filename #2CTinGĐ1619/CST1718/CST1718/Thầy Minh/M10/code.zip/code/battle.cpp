/*
If you are not authorized to access this system. Keep out!
 
            ....................../´¯/)
            ....................,/¯../
            .................../..../
            ............./´¯/'...'/´¯¯`·¸
            ........../'/.../..../......./¨¯\
            ........('(...´...´.... ¯~/'...')
            .........\.................'...../
            ..........''...\.......... _.·´
            ............\..............(
            ..............\.............\...
*/

#include <bits/stdc++.h>
using namespace std;
#define ll long long8
#define nmax 1001

struct type{
	int x,y,r;
	type() {x = y = r = 0;}
	type(int x, int y, int r): x(x), y(y), r(r) {}
} a[nmax];

int n;
vector<int> ans;
bool f[nmax][nmax], fre[nmax];

inline void dfs(int u){
	fre[u] = true;
	for (int v = 1; v <= n; v++)
		if (!fre[v] && f[u][v]) dfs(v);
}

int main(){
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	freopen("battle.inp","r",stdin);
	freopen("battle.out","w",stdout);

	cin >> n;
	do{
		ans.clear();		
		memset(f,false,sizeof(f)); memset(fre,false,sizeof(fre));

		for (int i = 1; i <= n; i++) {
			int x,y,r,e; cin >> x >> y >> r >> e;
			a[i] = type(x, y, r + e);

			for (int j = 1; j < i; j++) {
				int dx = a[i].x - a[j].x;
				int dy = a[i].y - a[j].y;
				int d = (int)sqrt(1.0 * dx * dx + 1.0 * dy * dy);
				if (d <= a[i].r + a[j].r) 
					f[i][j] = f[j][i] = true;
			}
		}

		int cnt = 0;
		for (int i = 1; i <= n; i++)
			if (!fre[i]) {
				cnt++;
				ans.push_back(i);
				dfs(i);
			}

		cout << cnt << ' ';
		for (int x: ans) cout << x << ' ';

		cin >> n;
	} while (n != 0);

	return 0;
}