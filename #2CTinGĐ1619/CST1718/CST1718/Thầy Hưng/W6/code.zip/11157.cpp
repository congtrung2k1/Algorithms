#include <iostream>
using namespace std;

int n,d, a[110];
bool iS[110], hit[110];

int solve()
{
    int ans = a[0];
    for (int i = 0; i < n; i++)
    {
        hit[i] = true;
        if (!iS[i+1]) ans = max(ans, a[i+1] - a[i]);
        else
        {
            ans = max(ans, a[i+2] - a[i]);
            i++;
        }
    }

    for (int i = n; i > 0; i--)
        if (!hit[i-1] || !iS[i-1]) ans = max(ans, a[i] - a[i-1]);
        else
        {
            ans = max(ans, a[i] - a[i-2]);
            i--;
        }
    return ans;
}

int main()
{
    freopen("11157.inp","r",stdin);
    freopen("11157.out","w",stdout);

int t; cin >> t;
for (int tt = 1; tt <= t; tt++)
{
    cin >> n >> d;
    for (int i = 0; i<n; i++)
    {
        char c,cc;
        cin >> c >> cc >> a[i];
        hit[i] = false;
        iS[i] = (c == 'S');
    }
    a[n] = d;
    hit[n] = false;
    iS[n] = false;

    printf("Case %d: %d\n", tt, solve());
}

    return 0;
}
