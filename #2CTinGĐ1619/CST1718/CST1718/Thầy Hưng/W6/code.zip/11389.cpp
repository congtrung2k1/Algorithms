#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

bool cmp(int a, int b){return a > b;}

int main()
{
    freopen("11389.inp","r",stdin);
    freopen("11389.out","w",stdout);

    int n,d,r, a[101], b[101];
    while (cin >> n)
    {
        if (!n) break;
        cin >> d >> r;
        for (int i = 1; i<=n; i++) cin >> a[i];
        for (int i = 1; i<=n; i++) cin >> b[i];
        sort(a+1,a+n+1);
        sort(b+1,b+n+1,cmp);

        long long ans = 0;
        for (int i = 1; i<=n; i++) ans += abs(min(0, d-(a[i]+b[i]))) * r;

        cout << ans << "\n";
    }

    return 0;
}
