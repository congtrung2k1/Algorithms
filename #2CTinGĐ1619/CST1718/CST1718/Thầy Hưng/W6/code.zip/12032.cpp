#include <iostream>
#include <math.h>
#include <stdio.h>>

using namespace std;

int n, nmax, a[100100];

bool check(int k){
    a[0] = 0;
    for (int i = 1; i<=n; i++)
        if (a[i] - a[i-1] > k) return false;
        else if (a[i]-a[i-1] == k) k--;
    return true;
}

void bns(int x){
    int l = 1, r = nmax, ans = nmax;
    while (l<=r){
        int m = (l+r) >> 1;
        if (check(m))
        {
            ans = ans > m ? m : ans;
            r = m-1;
        }
        else l = m + 1;
    }

    printf("Case %d: %d\n",x,ans);
}

int main(){
    freopen("12032.inp","r",stdin);
    freopen("12032.out","w",stdout);

int t,x = 0;
cin >> t;
while (x++ < t)
{
    cin >> n;
    for (int i = 1; i<=n; i++) {
        cin >> a[i];
        nmax = nmax < a[i] ? a[i] : nmax;
    }
    bns(x);
}

    return 0;
}
